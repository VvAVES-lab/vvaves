@echo off
title VvAVES Main (close this window to stop)
"%~dp0Terrarium.exe" --port 5101
