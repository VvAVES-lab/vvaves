@echo off
title VvAVES Preview (close this window to stop)
"%~dp0Terrarium.exe" --port 5110
